package org.e6;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.*;
import com.google.auth.oauth2.GoogleCredentials;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class CustomerApp extends JFrame implements ActionListener {

    private JTextField idField, lastNameField, firstNameField, phoneField;
    private JTextField newIdField, newLastNameField, newFirstNameField, newPhoneField;
    private JButton prevButton, nextButton, addButton;
    private FirebaseDatabase database;
    private DatabaseReference ref;
    private List<DataSnapshot> customerList;
    private int currentIndex = 0;

    public CustomerApp() {
        setTitle("Customer");
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Existing fields
        JLabel idLabel = new JLabel("ID:");
        idField = new JTextField(10);
        idField.setEditable(false);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameField = new JTextField(10);
        lastNameField.setEditable(false);

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameField = new JTextField(10);
        firstNameField.setEditable(false);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneField = new JTextField(10);
        phoneField.setEditable(false);

        prevButton = new JButton("Previous");
        nextButton = new JButton("Next");

        prevButton.addActionListener(this);
        nextButton.addActionListener(this);

        // Add new customer fields
        JLabel newIdLabel = new JLabel("New ID:");
        newIdField = new JTextField(10);

        JLabel newLastNameLabel = new JLabel("New Last Name:");
        newLastNameField = new JTextField(10);

        JLabel newFirstNameLabel = new JLabel("New First Name:");
        newFirstNameField = new JTextField(10);

        JLabel newPhoneLabel = new JLabel("New Phone:");
        newPhoneField = new JTextField(10);

        addButton = new JButton("Add New");
        addButton.addActionListener(this);

        // Add components to the frame
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(idLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(lastNameLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        add(lastNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(firstNameLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        add(firstNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(phoneLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        add(phoneField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(prevButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        add(nextButton, gbc);

        // New customer fields
        gbc.gridx = 0;
        gbc.gridy = 5;
        add(newIdLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        add(newIdField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        add(newLastNameLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 6;
        add(newLastNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        add(newFirstNameLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 7;
        add(newFirstNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 8;
        add(newPhoneLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 8;
        add(newPhoneField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 9;
        add(addButton, gbc);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setVisible(true);

        // Initialize Firebase
        initializeFirebase();
    }

    private void initializeFirebase() {
        try {
            InputStream serviceAccount = getClass().getClassLoader().getResourceAsStream("firebase/e6-y3-final-exam-firebase-adminsdk-54q2b-23dfee0937.json");

            if (serviceAccount == null) {
                throw new IllegalStateException("Firebase service account file not found");
            }

            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .setDatabaseUrl("https://e6-y3-final-exam-default-rtdb.firebaseio.com/")
                    .build();

            FirebaseApp.initializeApp(options);
            database = FirebaseDatabase.getInstance();
            ref = database.getReference("customers");

            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    customerList = new ArrayList<>();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        customerList.add(snapshot);
                    }
                    loadRecord(currentIndex);
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    System.out.println("Failed to read value: " + error.toException());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadRecord(int index) {
        if (customerList != null && !customerList.isEmpty() && index >= 0 && index < customerList.size()) {
            DataSnapshot snapshot = customerList.get(index);
            idField.setText(snapshot.child("customer_id").getValue(String.class));
            lastNameField.setText(snapshot.child("customer_last_name").getValue(String.class));
            firstNameField.setText(snapshot.child("customer_first_name").getValue(String.class));
            phoneField.setText(snapshot.child("customer_phone").getValue(String.class));
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == prevButton) {
            if (currentIndex > 0) {
                currentIndex--;
                loadRecord(currentIndex);
            }
        } else if (e.getSource() == nextButton) {
            if (currentIndex < customerList.size() - 1) {
                currentIndex++;
                loadRecord(currentIndex);
            }
        } else if (e.getSource() == addButton) {
            addNewCustomer();
        }
    }

    private void addNewCustomer() {
        String newId = newIdField.getText();
        String newLastName = newLastNameField.getText();
        String newFirstName = newFirstNameField.getText();
        String newPhone = newPhoneField.getText();

        if (newId.isEmpty() || newLastName.isEmpty() || newFirstName.isEmpty() || newPhone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields");
            return;
        }

        DatabaseReference newCustomerRef = ref.child(newId);
        newCustomerRef.child("customer_id").setValueAsync(newId);
        newCustomerRef.child("customer_last_name").setValueAsync(newLastName);
        newCustomerRef.child("customer_first_name").setValueAsync(newFirstName);
        newCustomerRef.child("customer_phone").setValueAsync(newPhone);

        JOptionPane.showMessageDialog(this, "Customer added successfully");

        // Clear the new customer fields
        newIdField.setText("");
        newLastNameField.setText("");
        newFirstNameField.setText("");
        newPhoneField.setText("");
    }

    public static void main(String[] args) {
        new CustomerApp();
    }
}
