package org.e6.customer_using_spring;

import com.google.firebase.database.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
public class CustomerService {

    private final DatabaseReference databaseReference;

    public CustomerService() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        this.databaseReference = database.getReference("customers");
    }

    public void addCustomer(Customer customer) {
        databaseReference.child(customer.getId().toString()).setValueAsync(customer);
    }

    public Customer getCustomerById(Long id) throws ExecutionException, InterruptedException {
        DatabaseReference ref = databaseReference.child(id.toString());
        CompletableFuture<Customer> future = new CompletableFuture<>();
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                Customer customer = snapshot.getValue(Customer.class);
                future.complete(customer);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                future.completeExceptionally(new RuntimeException("Database error: " + error.getMessage()));
            }
        });
        return future.get();
    }

    public List<Customer> getAllCustomers() throws ExecutionException, InterruptedException {
        CompletableFuture<List<Customer>> future = new CompletableFuture<>();
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                List<Customer> customers = StreamSupport.stream(snapshot.getChildren().spliterator(), false)
                        .map(childSnapshot -> childSnapshot.getValue(Customer.class))
                        .collect(Collectors.toList());
                future.complete(customers);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                future.completeExceptionally(new RuntimeException("Database error: " + error.getMessage()));
            }
        });
        return future.get();
    }

    public void updateCustomer(Long id, Customer customer) {
        databaseReference.child(id.toString()).setValueAsync(customer);
    }
}
