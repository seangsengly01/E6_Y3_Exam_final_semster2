package org.e6.customer_using_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerUsingSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
